# XVARM(XTORM) 연동 샘플

edms(`minervasoft.edms.external.inzent.xvarm.XVarmAPI`) 연동 방식을 그대로 옮긴 독립 샘플이다. 프레임워크 없이 JDK 8+ 와 벤더 jar 만 쓴다.

## 구성

| 파일 | 내용 |
|---|---|
| `XvarmConfig` | 접속 · 분류 설정(`config/xvarm.properties`) |
| `XvarmClient` | 등록(파일 · 스트림) · 조회(파일 · 메모리) · 교체 · 삭제 |
| `XvarmResult` | 결과 — `code` 0 = 성공, 그 외 실패(`error` = 엔진 `getLastError()`, -1 = 예외). 확인한 코드: 5 = 필수 속성 누락(예: `m_descr` 비움), 11 = 엔진 접속 실패 |
| `XvarmSample` | 명령줄 실행 예 |

## 준비 · 실행

1. `lib/` 에 `xtormapi_20210723.jar` 를 넣는다.
2. `config/xvarm.properties` 에 엔진 IP · 포트 · 계정 · Gateway · Class ID 를 적는다.
3. 빌드 · 실행
   ```
   build.bat
   run.bat config\xvarm.properties all C:\temp\test.pdf      # 등록 → 조회 → 교체 → 삭제
   run.bat config\xvarm.properties upload C:\temp\test.pdf
   run.bat config\xvarm.properties download 2022110502062401 C:\temp\out.pdf
   run.bat config\xvarm.properties replace  2022110502062401 C:\temp\test2.pdf
   run.bat config\xvarm.properties delete   2022110502062401
   ```
   Linux 는 `build.sh` · `run.sh`.

## 코드에서 쓰기

```java
XvarmClient xvarm = new XvarmClient(XvarmConfig.load("/app/config/xvarm.properties"));

XvarmResult r = xvarm.upload("/data/doc.pdf");
if (r.isSuccess()) {
    String elementId = r.getElementId();   // 짧은 ID — DB 에는 이것만 저장
}
xvarm.download(elementId, "/tmp/doc.pdf");
xvarm.delete(elementId);
```

## 알아 둘 것

- **ElementID**: 등록 결과는 짧은 ID(`2022110502062401`). 조회 · 교체 · 삭제는 `{gateway}::{짧은 ID}::{eclassid}` 전체 ID 로 부른다(`XvarmClient.fullId`). E-Class 를 여러 개 쓰면 E-Class 도 함께 저장해야 한다.
- **호출마다 접속 → 작업 → close**(edms 와 같음). 접속 객체를 필드에 두지 않아 한 인스턴스를 여러 스레드가 써도 된다(edms 원본은 싱글턴 필드라 동시 호출에 안전하지 않았다).
- **메모리 조회**: 벤더 API 가 `ByteArrayOutputStream` 만 받는다. 큰 파일은 파일 조회를 쓴다.
- **암호화**: 엔진 암호화 인자는 빈 값으로 둔다. edms 는 올리기 전 앱에서 파일을 암호화(MagicJCrypto)하고 받은 뒤 복호화했다 — 필요하면 `upload` 전 · `download` 후에 직접 넣는다.
- **교체**는 ID 를 유지하고 내용만 바꾼다.
- `xvarm.desc`(등록 설명 `m_descr`)를 비우면 엔진이 등록을 거부한다(코드 5). properties 는 ISO-8859-1 로 읽으니 값에 한글을 쓰지 않는다.
- 비밀번호를 로그에 남기지 않는다(`XvarmConfig.toString` 에서 뺐다).
