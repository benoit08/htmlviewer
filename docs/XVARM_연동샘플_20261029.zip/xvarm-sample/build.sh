#!/bin/sh
# JDK 8 이상. lib/xtormapi_*.jar 가 있어야 한다
mkdir -p classes
javac -encoding UTF-8 -cp "lib/*" -d classes src/main/java/sample/xvarm/*.java && \
echo "빌드 완료. 실행: ./run.sh config/xvarm.properties all /tmp/test.pdf"
