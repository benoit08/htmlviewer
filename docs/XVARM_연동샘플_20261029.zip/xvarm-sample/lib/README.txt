여기에 벤더 라이브러리 xtormapi_20210723.jar 를 넣는다(Inzent Xtorm for API V6, build.20210727).
참고 위치: edms WEB-INF/lib/xtormapi_20210723.jar
