@echo off
java -Dfile.encoding=UTF-8 -cp "classes;lib/*" sample.xvarm.XvarmSample %*
