@echo off
rem JDK 8+ / put lib\xtormapi_*.jar first
if not exist classes mkdir classes
javac -encoding UTF-8 -cp "lib/*" -d classes src\main\java\sample\xvarm\*.java || exit /b 1
echo Build OK. Run: run.bat config\xvarm.properties all C:\temp\test.pdf
