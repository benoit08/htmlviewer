package sample.xvarm;

import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/**
 * 사용법: java -cp "classes;lib/*" sample.xvarm.XvarmSample <설정파일> <명령> [인자...]
 *   all      <파일>           등록 → 조회(파일·메모리) → 교체 → 삭제를 차례로
 *   upload   <파일>
 *   download <짧은ID> <저장경로>
 *   replace  <짧은ID> <파일>
 *   delete   <짧은ID>
 */
public class XvarmSample {

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.out.println("사용법: XvarmSample <설정파일> <all|upload|download|replace|delete> [인자...]");
            return;
        }
        XvarmConfig config = XvarmConfig.load(args[0]);
        XvarmClient client = new XvarmClient(config);
        System.out.println("엔진: " + config);

        String[] a = Arrays.copyOfRange(args, 2, args.length);
        switch (args[1]) {
            case "all":
                all(client, Paths.get(a[0]));
                break;
            case "upload":
                print("등록", client.upload(a[0]));
                break;
            case "download":
                print("조회", client.download(a[0], a[1]));
                break;
            case "replace":
                print("교체", client.replace(a[0], a[1]));
                break;
            case "delete":
                print("삭제", client.delete(a[0]));
                break;
            default:
                System.out.println("모르는 명령: " + args[1]);
        }
    }

    private static void all(XvarmClient client, Path file) throws Exception {
        XvarmResult up = print("1 등록", client.upload(file.toString()));
        if (!up.isSuccess()) {
            return;
        }
        String id = up.getElementId();
        System.out.println("  전체 ID: " + client.fullId(id));

        Path saved = Files.createTempFile("xvarm-", "-" + file.getFileName());
        print("2 조회(파일)", client.download(id, saved.toString()));
        System.out.println("  원본과 같음: " + Arrays.equals(Files.readAllBytes(file), Files.readAllBytes(saved)));
        Files.deleteIfExists(saved);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        print("3 조회(메모리)", client.download(id, out));
        System.out.println("  " + out.size() + " bytes");

        print("4 교체(같은 파일)", client.replace(id, file.toString()));
        print("5 삭제", client.delete(id));
        print("6 삭제 후 조회 — 실패가 정상", client.download(id, new ByteArrayOutputStream()));
    }

    private static XvarmResult print(String step, XvarmResult r) {
        System.out.println(step + ": " + r);
        return r;
    }
}
