package sample.xvarm;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

public class XvarmConfig {

    private final String ip;
    private final int port;
    private final String id;
    private final String pw;
    private final String desc;
    private final String gateway;
    private final String cClassId;
    private final String eClassId;
    private final String sClassId;

    public XvarmConfig(String ip, int port, String id, String pw, String desc,
                       String gateway, String cClassId, String eClassId, String sClassId) {
        this.ip = ip;
        this.port = port;
        this.id = id;
        this.pw = pw;
        this.desc = desc;
        this.gateway = gateway;
        this.cClassId = cClassId;
        this.eClassId = eClassId;
        this.sClassId = sClassId;
    }

    public static XvarmConfig load(String path) throws IOException {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(Paths.get(path))) {
            p.load(in);
        }
        return new XvarmConfig(
                required(p, "xvarm.ip"),
                Integer.parseInt(required(p, "xvarm.port")),
                required(p, "xvarm.id"),
                required(p, "xvarm.pw"),
                required(p, "xvarm.desc"),
                required(p, "xvarm.gateway"),
                required(p, "xvarm.cclassid"),
                required(p, "xvarm.eclassid"),
                required(p, "xvarm.sclassid"));
    }

    private static String required(Properties p, String key) {
        String v = p.getProperty(key);
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException("설정 누락: " + key);
        }
        return v.trim();
    }

    public String getIp() { return ip; }
    public int getPort() { return port; }
    public String getId() { return id; }
    public String getPw() { return pw; }
    public String getDesc() { return desc; }
    public String getGateway() { return gateway; }
    public String getCClassId() { return cClassId; }
    public String getEClassId() { return eClassId; }
    public String getSClassId() { return sClassId; }

    @Override
    public String toString() {
        return ip + ":" + port + " user=" + id + " gateway=" + gateway
                + " cclass=" + cClassId + " eclass=" + eClassId + " sclass=" + sClassId;
    }
}
