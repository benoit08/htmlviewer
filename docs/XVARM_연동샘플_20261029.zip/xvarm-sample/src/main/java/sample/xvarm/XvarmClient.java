package sample.xvarm;

import com.windfire.apis.asys.asysUsrElement;
import com.windfire.apis.asysConnectData;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * XVARM(XTORM) 엔진 연동. 호출마다 접속 → 작업 1회 → close 한다.
 * 접속 객체를 필드에 두지 않으므로 여러 스레드가 같은 인스턴스를 써도 된다.
 */
public class XvarmClient {

    private static final int CLIENT_ERROR = -1;

    private final XvarmConfig config;

    public XvarmClient(XvarmConfig config) {
        this.config = config;
    }

    public XvarmResult upload(String filePath) {
        return upload(filePath, config.getCClassId());
    }

    public XvarmResult upload(String filePath, String cClassId) {
        return execute((con, usr) -> {
            usr.m_localFile = filePath;
            setClasses(usr, cClassId);
            int ret = usr.create(config.getGateway());
            return ret == 0 ? XvarmResult.ok(usr.getShortID()) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    public XvarmResult upload(InputStream in, String cClassId) {
        return execute((con, usr) -> {
            setClasses(usr, cClassId);
            // 3·4번째 인자는 엔진 암호화용 — 쓰지 않는다
            int ret = usr.create(config.getGateway(), in, "", "");
            return ret == 0 ? XvarmResult.ok(usr.getShortID()) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    /** savePath = 저장할 파일의 전체 경로 */
    public XvarmResult download(String elementId, String savePath) {
        return execute((con, usr) -> {
            usr.m_elementId = fullId(elementId);
            int ret = usr.getContent(savePath);
            return ret == 0 ? XvarmResult.ok(elementId) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    /** 벤더 API 가 ByteArrayOutputStream 만 받아 파일 전체가 메모리에 올라온다 */
    public XvarmResult download(String elementId, ByteArrayOutputStream out) {
        return execute((con, usr) -> {
            usr.m_elementId = fullId(elementId);
            int ret = usr.getContent(out, "", "");
            return ret == 0 ? XvarmResult.ok(elementId) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    public XvarmResult replace(String elementId, String filePath) {
        return execute((con, usr) -> {
            usr.m_elementId = fullId(elementId);
            int ret = usr.replaceContent(filePath);
            return ret == 0 ? XvarmResult.ok(elementId) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    public XvarmResult delete(String elementId) {
        return execute((con, usr) -> {
            usr.m_elementId = fullId(elementId);
            int ret = usr.delete();
            return ret == 0 ? XvarmResult.ok(elementId) : XvarmResult.fail(ret, usr.getLastError());
        });
    }

    /** 조회 · 교체 · 삭제는 등록 때의 E-Class 로 만든 전체 ID 를 쓴다 */
    public String fullId(String shortId) {
        return config.getGateway() + "::" + shortId + "::" + config.getEClassId();
    }

    private void setClasses(asysUsrElement usr, String cClassId) {
        usr.m_descr = config.getDesc();
        usr.m_cClassId = cClassId;
        usr.m_eClassId = config.getEClassId();
        usr.m_userSClass = config.getSClassId();
    }

    private XvarmResult execute(Work work) {
        asysConnectData con = null;
        try {
            con = new asysConnectData(config.getIp(), config.getPort(), config.getDesc(), config.getId(), config.getPw());
            return work.run(con, new asysUsrElement(con));
        } catch (Exception e) {
            return XvarmResult.fail(CLIENT_ERROR, e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }

    private interface Work {
        XvarmResult run(asysConnectData con, asysUsrElement usr) throws Exception;
    }
}
