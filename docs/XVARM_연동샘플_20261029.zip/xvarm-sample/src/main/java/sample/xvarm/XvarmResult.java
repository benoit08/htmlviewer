package sample.xvarm;

public class XvarmResult {

    private final int code;
    private final String elementId;
    private final String error;

    private XvarmResult(int code, String elementId, String error) {
        this.code = code;
        this.elementId = elementId;
        this.error = error;
    }

    public static XvarmResult ok(String elementId) {
        return new XvarmResult(0, elementId, "");
    }

    public static XvarmResult fail(int code, String error) {
        return new XvarmResult(code, "", error == null ? "" : error);
    }

    public boolean isSuccess() { return code == 0; }
    public int getCode() { return code; }
    /** 짧은 ID — 등록 · 교체 결과에만 있다 */
    public String getElementId() { return elementId; }
    public String getError() { return error; }

    @Override
    public String toString() {
        return isSuccess() ? "성공 elementId=" + elementId : "실패 code=" + code + " " + error;
    }
}
