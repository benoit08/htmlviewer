#!/bin/sh
java -cp "classes:lib/*" sample.xvarm.XvarmSample "$@"
